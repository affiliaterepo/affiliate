# Downloadable marketing workbooks

- `campaigns.csv`: track audience, permission and review status.
- `blurb-templates.csv`: starter educational message with disclosure/evidence fields.
- `30-day-plan.csv`: one achievable learning/review step per day.
- `measurement-sheet.csv`: record figures from separate verified systems.

Use a spreadsheet application to open these files. Do not upload sensitive personal records. All examples are instructional and have no claimed real sales or delivery.
