#!/usr/bin/env python3
"""No-dependency static release audit for Github Pages artifacts."""
import csv,re,sys,xml.etree.ElementTree as ET,json
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
p=Path(sys.argv[1] if len(sys.argv)>1 else '_site').resolve()
base=(p/'site-config.txt').read_text().split('Published base URL: ')[1].splitlines()[0].rstrip('/')
path=urlsplit(base).path.rstrip('/')
class P(HTMLParser):
 def __init__(self):super().__init__();self.anchors=[];self.assets=[];self.meta=[];self.headings=0;self.urls=[]
 def handle_starttag(self,tag,atts):
  d=dict(atts)
  if tag=='h1':self.headings+=1
  if tag=='meta':self.meta.append(d)
  if tag=='link':self.urls.append(d)
  for attr in ('src','href','action'):
   if attr in d:self.anchors.append(d[attr])
errors=[];files=list(p.rglob('*.html'));guidefiles=list((p/'guides').glob('*.html'))
if len(guidefiles)!=101:errors.append('Expect 100 guides plus index, got '+str(len(guidefiles)))
expected_verify='<head><meta name="google-site-verification" content="g_9a3iWAxqoXSpLnCUlYJ4fH82gOT8k0X8KF8OoleBY" />'
for f in files:
 raw=f.read_text(encoding='utf8');parser=P();parser.feed(raw)
 if expected_verify not in raw:errors.append('verification '+str(f))
 if parser.headings!=1:errors.append('H1 '+str(f))
 if 'G-JSTXEL562F' in raw and f.name!='privacy-policy.html':errors.append('Unexpected GA '+str(f))
 cans=[x.get('href') for x in parser.urls if x.get('rel')=='canonical']
 if len(cans)!=1 or not cans[0].startswith(base+'/'):errors.append('canonical '+str(f))
 for u in parser.anchors:
  if u.startswith(path+'/'):
   rel=u[len(path):].split('#')[0].split('?')[0]
   dest=p/(rel.lstrip('/') or 'index.html')
   if not dest.is_file(): errors.append('broken: '+str(f)+' -> '+u)
  if u.startswith('/') and not u.startswith(path+'/'):errors.append('prefix missing '+str(f)+' -> '+u)
ns={'x':'http://www.sitemaps.org/schemas/sitemap/0.9'}
xml=ET.parse(p/'sitemap.xml');locs=[el.text for el in xml.findall('x:url/x:loc',ns)]
for u in locs:
 if not u.startswith(base+'/'):errors.append('invalid sitemap URL '+str(u))
 dest=p/(urlsplit(u).path[len(path):].lstrip('/') or 'index.html')
 if not dest.is_file():errors.append('sitemap file missing '+str(u))
if len(locs)!=112:errors.append('sitemap length '+str(len(locs)))
if not (p/'.nojekyll').exists():errors.append('missing .nojekyll')
if len(set(locs))!=len(locs):errors.append('duplicate sitemap URLs')
print(json.dumps({'checked_html_files':len(files),'guide_pages':len(guidefiles)-1,'sitemap_entries':len(locs),'site_url':base+'/','errors':errors[:30]},indent=2))
if errors:sys.exit(1)
