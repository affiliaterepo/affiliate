#!/usr/bin/env python3
"""Static HTML, sitemap, links and metadata audit with precise coverage report."""
from pathlib import Path
from lxml import html, etree
from urllib.parse import urlsplit
import json,re,subprocess
root=Path(__file__).resolve().parents[1]
htmls=[f for f in root.rglob('*.html') if '_site' not in f.relative_to(root).parts]
titles={};descs={};canonicals={}; errors=[]; malformed=[]
for f in htmls:
  try:
    tree=html.fromstring(f.read_text())
    title=tree.xpath('//title/text()')[0]
    desc=tree.xpath('//meta[@name="description"]/@content')[0]
    can=tree.xpath('//link[@rel="canonical"]/@href')[0]
    if f.name!='404.html' and f.name!='affiliate-disclosure.html':
      for mapping,k in [(titles,title),(descs,desc),(canonicals,can)]:
        if k in mapping: errors.append(f'DUPLICATE metadata {k[:100]} at {f} and {mapping[k]}')
        mapping[k]=str(f)
    if len(tree.xpath('//h1'))!=1:errors.append('H1 issue '+str(f))
    if not tree.xpath('//meta[@name="viewport"]'): errors.append('Viewport missing '+str(f))
    if f.read_text().split('<head>',1)[1].split('\n',1)[0]!='<meta name="google-site-verification" content="g_9a3iWAxqoXSpLnCUlYJ4fH82gOT8k0X8KF8OoleBY" />':errors.append('verification placement '+str(f))
    if 'G-JSTXEL562F' in f.read_text() and f.name!='privacy-policy.html':errors.append('Unexpected inline GA ID '+str(f))
    for script in tree.xpath('//script[@type="application/ld+json"]/text()'):
      try:json.loads(script)
      except Exception: errors.append('Invalid JSON-LD '+str(f))
    for anchor in tree.xpath('//a[@href]'):
      url=anchor.get('href')
      if url.startswith('/'):
        dest=root/(url.split('#',1)[0].split('?',1)[0].lstrip('/') or 'index.html')
        if not dest.exists():errors.append(f'Broken internal link {url} in {f}')
      elif url.startswith(('https://','http://','mailto:','#')): pass
      else:malformed.append((str(f),url))
  except Exception as e:errors.append(f'Cannot parse {f}: {e}')
with (root/'sitemap.xml').open() as f:
 sitemap=etree.parse(f)
locs=sitemap.xpath('//*[local-name()="loc"]/text()')
for loc in locs:
 path=urlsplit(loc).path
 if not (root/(path.lstrip('/') or 'index.html')).is_file(): errors.append('Sitemap orphan '+loc)
for js in (root/'assets/js').glob('*.js'):
 check=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
 if check.returncode:errors.append('Invalid JavaScript '+str(js)+': '+check.stderr[:100])
assert not errors,'\n'.join(errors)
result={'checked_html':len(htmls),'unique_titles':len(titles),'unique_meta_descriptions':len(descs),'unique_canonicals':len(canonicals),'sitemap_entries':len(locs),'malformed_local_link_examples':malformed[:3],'errors':errors,'js_syntax':'PASS'}
print(json.dumps(result,indent=2))
