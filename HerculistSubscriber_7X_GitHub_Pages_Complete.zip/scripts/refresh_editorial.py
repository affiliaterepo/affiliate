#!/usr/bin/env python3
"""Generate a more focused, independently useful guide edition from 100 editorial briefs.
This purposefully replaces the earlier shared long-form filler with practical specific exercises.
Run after build.py; deterministic and standard-library only.
"""
import csv,html,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SEEDS=json.loads((ROOT/'config/guide-metadata.json').read_text())
LINKS=json.loads((ROOT/'config/links.json').read_text())
def h(x):return html.escape(str(x),quote=True)
# Each cluster teaches a different discipline, not the same mechanical 900-word scaffold.
GROUPS={
'Herculist foundations':{
 'headline':'Start with a credible promotion, not a volume target',
 'method':['Identify the person who will see the message and one problem that your destination actually helps solve.','Open the destination as if you were a first-time visitor. Look for a plain-English explanation, visible terms and a working next step.','Check your own membership rules or current provider documentation before any external submission. Save what you verified and when.','Record which event can be measured: a page visit, a completed form, or a verified order. Never use one label for another.'],
 'measurement':'A clean source-to-page journey, a defensible message and a named measurement event are a better first milestone than high message volume.',
 'exercise':'Write the visitor promise in twelve words, then verify that the first screen of the destination honors it.'},
'Seven daily workflow':{
 'headline':'Plan seven decisions; send only what is permitted',
 'method':['Create distinct planning slots for research, drafting, editing, compliance, an eligible manual placement, evidence logging and review.','Separate scheduled work from confirmed work. A completed planner checkbox has no connection to any third-party posting API.','Allocate each slot a realistic time limit. If a placement is unavailable, do a quality or research task rather than evading frequency limits.','At the end of the day, compare what was planned, what was actually done, and what you can prove with a source record.'],
 'measurement':'Track minutes used, verified manual actions and the most important learning from the day; never infer message deliveries.',
 'exercise':'Make a seven-row schedule and put the proof needed for each completed status into its own column.'},
'Ad copywriting':{
 'headline':'Write for relevance before you write for attention',
 'method':['Describe the reader situation without assuming the reader wants to buy immediately.','Write a clear benefit that can be supported by the destination content or provider documentation.','Draft one subject line, one short supporting statement and one next action. Avoid invented scarcity, fake reply prefixes and earnings promises.','Read the destination next to the blurb. Remove any promise that the page does not explain or fulfill.'],
 'measurement':'Review clarity, claim support and the match between the ad and the destination; click rate alone can reward misleading copy.',
 'exercise':'Produce a teaching version and a comparison version of your message; identify the different question each addresses.'},
'Traffic generation':{
 'headline':'Match each channel with the correct expectation',
 'method':['State whether the traffic source is educational, search-driven, community-driven, incentivized or paid placement.','Choose one reader question and a page that answers it without a forced detour.','Tag campaigns consistently where allowed. Preserve source names separately rather than merging different channels.','Inspect behavior after the click and compare it with the channel objective, acknowledging incomplete attribution.'],
 'measurement':'Track relevant visits and meaningful actions, while separating estimated source quality from verified conversions.',
 'exercise':'Compare two channels on audience purpose, spend, allowed placement, measurement and uncertainty.'},
'Affiliate marketing funnels':{
 'headline':'Make the next step understandable and voluntary',
 'method':['Sketch the path from source message to landing page to optional sign-up or recommendation.','Show any price, prerequisites, account needs and affiliate relationship at the point where the visitor decides.','Use an explicit opt-in for marketing emails; explain the content and unsubscribe route.','Verify the relevant conversion event using records from the actual form or authorized seller, not a mere button click.'],
 'measurement':'A funnel audit should distinguish visits, consented subscriptions and approved sales; they are different events.',
 'exercise':'Draw a three-box visitor journey and write what a person expects and receives at each step.'},
'Herculist product education':{
 'headline':'Study the provider details before choosing an option',
 'method':['Read the latest provider description and relevant account terms for the named offering.','Record confirmed price, renewal terms, audience type and eligibility only when each is visible in an official source.','Check that the referral destination loads correctly, identifies the expected product and explains what is included.','Compare the option with one lower-cost alternative and document what remains unknown.'],
 'measurement':'A comparison table is useful even when vendor data are incomplete; label unknown values rather than filling them with guesses.',
 'exercise':'Create a vendor fact sheet with confirmed, unverified and not-applicable columns.'},
'Tracking and analytics':{
 'headline':'Give every number a denominator and a source',
 'method':['Define the event before calculating a rate: delivered impressions, actual visits, opt-ins or approved transactions.','Capture a date range and attribution boundary. Two tools may differ because their sessions and event filters differ.','Use a spreadsheet or the browser planner for observations, and record where each number originated.','Change one variable at a time in a small test; do not call statistical noise a proven win.'],
 'measurement':'Rates need compatible numerator and denominator definitions. Financial return requires actual cost and verified payment, not forecast commissions.',
 'exercise':'Build a mini-report with source, time period, event definition, count and interpretation.'},
'AI and productivity':{
 'headline':'Use AI for drafts; keep judgment with the marketer',
 'method':['Start with a genuine reader question, the allowed platform and the facts you can substantiate.','Request alternatives or organizational help, then check each generated statement against your source material.','Rewrite generic copy around a real lesson, relevant limitation or independently confirmed feature.','Remove fabricated testimonials, earnings examples, unverifiable statistics and misleading automated-posting claims.'],
 'measurement':'Evaluate saved preparation time and publishing accuracy separately; a fluent AI draft is not evidence of campaign effectiveness.',
 'exercise':'Compare an initial AI draft with your corrected version and annotate three factual edits.'},
'Lead generation and growth':{
 'headline':'Earn permission before requesting attention again',
 'method':['Offer a resource with a clear purpose and delivery expectation; do not conceal a paid offer behind a vague headline.','Explain whether the email list contains educational messages, occasional promotional links or both.','Only record subscribers who intentionally consented, and retain suitable evidence through the email provider.','Review engagement and unsubscribes in context; never pressure visitors to sign up to read open resources.'],
 'measurement':'Count permission-based subscribers and actual engagement, not form views or unverified sign-up attempts.',
 'exercise':'Write a newsletter invitation naming the topic, sender, email frequency if known, and an obvious unsubscribe expectation.'},
'Product support and advanced education':{
 'headline':'Document what the browser tool really does',
 'method':['Open the app and create a practice campaign with a non-sensitive URL.','Save a blurb, assign the next manual task and mark statuses only when you performed the work.','Use the reporting journal for figures you personally obtained from trustworthy sources.','Export a JSON backup; test importing it in a separate browser profile before relying on it as your only copy.'],
 'measurement':'The static planner keeps local records. It has no seller entitlement checks, server storage or authorized third-party posting connector.',
 'exercise':'Follow the feature once from a blank screen and write the exact steps another beginner would need.'}
}
# Correct source cluster names from the editorial metadata.
CLUSTER_ALIAS={
 'Tracking and analytics':'Tracking and analytics',
 'AI and marketing productivity':'AI and marketing productivity',
 'Lead generation and growth':'Lead generation and growth',
 'Product support and advanced education':'Product support and advanced education',
}

def section(s,n):
 c=GROUPS.get(s['cluster'])
 if not c:
  raise ValueError('Missing theme '+str(s['cluster']))
 title=h(s['title']);focus=h(s['focus']);task=h(s['task']);scenario=h(s['scenario']);pitfall=h(s['pitfall'])
 # The source brief is itself unique: focus, practice task, example and mistake all differ by page.
 method=c['method'];offset=(n-1)%4
 order=method[offset:]+method[:offset]
 steps=''.join(f'<li><strong>{i}. </strong>{h(step)} For this lesson, apply the step specifically to: <em>{focus.lower()}</em>.</li>' if i==2 else f'<li><strong>{i}. </strong>{h(step)}</li>' for i,step in enumerate(order,1))
 # Unique practical work is deliberately prioritized over chasing an arbitrary word count.
 if 'subject' in s['title'].lower() or 'blurb' in s['title'].lower() or s['cluster']=='Ad copywriting':
  lab='<h3>Copy desk exercise</h3><p>Draft version A as a direct educational invitation and version B as a problem-and-solution introduction. In both, include a link to the same appropriate page. Underline anything a skeptical reader might construe as a measurable promise. For each underlined claim, link to evidence or delete it.</p>'
 elif s['cluster']=='Tracking and analytics':
  lab='<h3>Measurement lab</h3><p>Create a small ledger with columns for date, source, counted event, definition, observed amount and proof. If calculating a rate, write the numerator and denominator in words before entering figures. A rate derived from incompatible windows should be marked unusable instead of averaged.</p>'
 elif s['cluster']=='Herculist product education':
  lab='<h3>Provider verification record</h3><p>Visit the actual provider and note when the information was checked. Record price, whether access renews, traffic delivery description, eligibility, refund conditions and permitted advertising methods only where they are confirmed. A supplied referral code is not proof that an offer remains active.</p>'
 elif s['cluster']=='AI and productivity':
  lab='<h3>Accuracy review</h3><p>Highlight every number, guarantee, date, feature or named provider in a draft. Classify it as directly checked, illustrative, inferred or unknown. Remove the inferred and unknown sales claims. Keep a change log identifying what human review added to the material.</p>'
 elif s['cluster']=='Lead generation and growth' or s['cluster']=='Affiliate marketing funnels':
  lab='<h3>Visitor journey audit</h3><p>Imagine a person who is interested in the topic but does not want to subscribe or buy. Can they still read the educational part? Then imagine someone who does subscribe: is the sender, marketing purpose and unsubscribe route clear before submitting their address?</p>'
 else:
  lab='<h3>Practice without spending money</h3><p>Use a sample campaign, a draft destination page or a worksheet before purchasing ads. Look for broken links, unsupported statements and ambiguous event labels. Do not log a plan as a successfully delivered external promotion.</p>'
 candidates=['What must be true for this advice to help the reader?', 'What evidence would disprove the initial idea?', 'Which action is under your control and which outcome depends on other people?', 'How could the same message be misunderstood by a first-time visitor?']
 q1=candidates[(n-1)%4];q2=candidates[(n+1)%4]
 return f"""<p class="eyebrow">Field guide {n:02d} / 100 · {h(s['cluster'])}</p><h1>{title}</h1>
 <p class="lead">{focus}. This guide turns that aim into a usable exercise for independent affiliate marketers. Its purpose is to help you make a responsible choice, not to promise specific advertising outcomes.</p>
 <div class="takeaway"><p class="eyebrow">The central idea</p><h2>{h(c['headline'])}</h2><p>{h(c['measurement'])}</p></div>
 <h2>What to decide before doing anything</h2><p>Start with a specific situation rather than a generic objective. Ask who needs this information, what they are likely to know already, and what the destination can actually deliver. For <strong>{title.lower()}</strong>, the central question is whether you can {focus[0].lower()+focus[1:]} without blurring the distinction between an action and a result.</p>
 <p>There are two paths worth separating. One is preparation: comparing alternatives, writing drafts, checking platform policy and organizing evidence. The other is delivery: a submission accepted by a third party, a visitor taking an action, or a sale verified through the merchant. Your checklist can document the first path; it cannot certify the second.</p>
 <h2>A real-world-style scenario to work through</h2><blockquote><p>{scenario}.</p></blockquote>
 <p>Picture the person at the other end of this situation. What would they see before clicking, and what would they discover immediately afterward? If the destination makes extra demands, such as registering with another service, disclose them. If the scenario needs external performance numbers, use a placeholder labelled hypothetical until you have evidence.</p>
 <h2>A practical method</h2><ol>{steps}</ol>
 <p>Now complete the distinctive assignment for this topic: <strong>{task}.</strong> Write down how you would know the exercise was finished, the evidence you would preserve, and one condition that would make you stop or revise it. Choose a small scope that can be tested safely.</p>
 <h2>Build a reusable field worksheet</h2><p>Open a plain text file or your campaign planner. Give the record this guide's title and add these fields: audience question, destination URL, promise made, observed event, evidence source, cost if any, date checked, and next review date. Copy the following prompt into the notes:</p>
 <blockquote><p>“For {title.lower()}, my intended reader wants to ______. I will {task[0].lower()+task[1:]}. I can verify completion by ______. The risk I need to address is ______.”</p></blockquote>
 {lab}
 <p><strong>Self-check:</strong> {h(c['exercise'])} Record the first version before revising it so the improvement is visible. If the destination is a paid or affiliate service, label the referral, confirm the current offer and avoid unsubstantiated results.</p>
 <h2>What can go wrong?</h2><p><strong>Watch for this exact pitfall: {pitfall.lower()}.</strong> It may appear harmless in a draft, but it changes the meaning of the message or the evidence being reported. Correct it by asking two questions: {h(q1)} {h(q2)}</p>
 <p>Some uncertainty cannot be resolved inside a static website. Vendor accounts may have different features; advertisements may require human approval; visitors may decline; and attribution may be incomplete. Report these unknowns as unknowns. Never substitute a guessed click total, earnings figure, provider price or approval status.</p>
 <h2>Decide what happens next</h2><p>Use a short review: Was the visitor promise accurate? Did the page work on a phone? Were disclosure and consent clear? Did your record reflect only verified actions? If the answers are solid, take the next permitted step; otherwise correct the material before increasing exposure.</p><p class="fine">This is independent educational content. The site cannot send Herculist advertisements, connect paid accounts or confirm sales.</p>"""

total=0
for n,s in enumerate(SEEDS,1):
 f=ROOT/s['path'].lstrip('/')
 old=f.read_text(encoding='utf8')
 start=old.index('<article class="article" id="guide-article">')
 end=old.index('</article>',start)+len('</article>')
 text=section(s,n)
 if n>1: text+=f'<p class="step-next"><a data-guide-engagement href="{h(SEEDS[n-2]["path"])}">← Previous lesson</a></p>'
 if n<100: text+=f'<p class="step-next"><a data-guide-engagement href="{h(SEEDS[n]["path"])}">Next lesson: {h(SEEDS[n]["title"])} →</a></p>'
 text+='<div class="card"><h3>Make it usable</h3><p>Keep your notes in the free <a href="/app/index.html">7X browser planner</a> or download the <a href="/resources/measurement-sheet.csv">measurement worksheet</a>. External promotions remain manual and subject to provider policies.</p></div>'
 if n in (2,3,11,31,34,35,41,61,81):
  text+='<section class="resource-inline"><h2>Optional independent resource</h2><p>Want to compare campaign tools? Visit the provider directly, check the current terms and decide whether its features fit your needs. This is a compensated referral link, not a necessary step in the lesson.</p><a class="btn secondary" rel="sponsored nofollow noopener noreferrer" target="_blank" data-affiliate="leadsleap" href="'+h(LINKS['leadsleap']['url'])+'">Explore LeadsLeap options</a></section>'
 if n%10==0:
  text+='<div class="callout"><h3>Extra resource</h3><p>For more planning ideas, see the <a href="/newsletter.html">optional educational newsletter</a>. Access to the guide library never requires email signup.</p></div>'
 replaced=old[:start]+'<article class="article" id="guide-article">'+text+'</article>'+old[end:]
 f.write_text(replaced,encoding='utf8')
 words=len(re.findall(r"\b[\w'-]+\b",re.sub('<[^>]*>',' ',text)))
 s['editorial_words']=words;total+=words
with (ROOT/'content-inventory.csv').open('w',newline='',encoding='utf8') as f:
 w=csv.writer(f);w.writerow(['index','cluster','title','path','editorial_words']);w.writerows((s['index'],s['cluster'],s['title'],s['path'],s['editorial_words']) for s in SEEDS)
(ROOT/'config/guide-metadata.json').write_text(json.dumps(SEEDS,ensure_ascii=False,indent=2),encoding='utf8')
print(f'Fresh editorial guide words (not padded to 100,000): {total:,} across {len(SEEDS)} pages')


# Distinct homepage presentation and transparent SEO copy.
home=ROOT/'index.html'
source=home.read_text(encoding='utf8')
if '<section class="hero">' in source:
 start=source.index('<section class="hero">');end=source.index('</section>',start)+len('</section>')
else:
 start=end=-1
original_hero='''<section class="hero hero-studio"><div class="container hero-stage"><div class="hero-copy"><p class="eyebrow">HERCULIST SUBSCRIBER · INDEPENDENT TOOLKIT</p><h1>Make every promotion <span class="glow">more intentional.</span></h1><p class="hero-sub">THE 7X DAILY PROMOTION PLAYBOOK</p><p class="lead">Less copy-and-paste chaos. More control over your advertising drafts, campaign notes, daily priorities, and follow-up decisions. Built for practical marketers who care about what happens after a click.</p><p>Plan seven meaningful workflow actions, then send advertisements manually wherever your account rules allow. This is a planning and education system — not a bulk-mailing bot.</p><div class="actions"><a class="btn green" data-product-cta href="/app/index.html">OPEN THE FREE 7X WORKSPACE</a><a class="btn secondary" data-product-cta href="/guides/index.html">BROWSE 100 FIELD GUIDES</a></div><p class="fine">Available today: browser-local campaign planner, editable blurbs, simple reporting, downloadable CSV workbooks and scenario calculators. No auto-submission, paid account login or independently verified conversion feeds.</p></div><div class="hero-dashboard" role="img" aria-label="Illustration of the actual seven manual promotion-planning stages; not live activity statistics"><div class="dashboard-label"><span class="signal"></span> WORKFLOW VIEW · EXAMPLE ONLY</div><div class="dashboard-top"><strong>Today’s priority board</strong><span class="dashboard-tag">7 stages</span></div><div class="dashboard-actions"><span>01 <b>Research</b><em>Plan</em></span><span>02 <b>Draft</b><em>Write</em></span><span>03 <b>Review</b><em>Refine</em></span><span>04 <b>Rules</b><em>Check</em></span><span>05 <b>Manual action</b><em>If allowed</em></span><span>06 <b>Log</b><em>Record</em></span><span>07 <b>Learn</b><em>Improve</em></span></div><p class="dashboard-foot">Organize decisions. Keep your evidence. Make no promises you cannot check.</p></div></div></section>'''
if start>=0:source=source[:start]+original_hero+source[end:]
source=source.replace('What the product includes','Useful features, not imaginary features')
source=source.replace('Seven useful actions, not seven unapproved submissions','Seven focused activities. Zero automatic submissions.')
source=source.replace('Explore practical learning resources','Practical reading for marketers who want clarity')
source=source.replace('Preview the real planning interface','Your campaign command center, without the guesswork')
source=source.replace('Review the 7X Daily Promotion System offer','Examine the offer and actual purchase terms')
source=source.replace('7X Daily Promotion System — Ethical Campaign Planner','7X Practical Campaign Workspace')
home.write_text(source,encoding='utf8')
# Library copy acknowledges editorial judgment, avoids an SEO-first claim.
lib=ROOT/'guides/index.html'
t=lib.read_text(encoding='utf8').replace('100 practical affiliate marketing guides','The Herculist Subscriber learning library')
t=t.replace('Browse distinct lessons spanning advertising fundamentals, blurb writing, ethical traffic, funnels, analytics, productivity and product usage. Pages are generated from a curated content inventory and require human editorial review before broad promotion.',
          'Explore 100 topic-led field guides with concrete practice assignments, worked marketing situations and explicit limitations. Use them to sharpen your own drafts and campaign decisions. The publication should still receive human fact-checking and expert editorial review before mass promotion.')
lib.write_text(t,encoding='utf8')
# Updated visual design has no external visual/font dependencies.
css=ROOT/'assets/css/site.css'
if '/* GitHub edition: original campaign studio art direction' not in css.read_text(encoding='utf8'):
 css.write_text(css.read_text(encoding='utf8')+'''\n/* GitHub edition: original campaign studio art direction, built entirely with CSS. */
:root{--panel:#18202a;--gold:#f5dc69;--green:#47d78c;--blue:#76dffc;--stroke:#394353;--radius:18px}
body{background:#0c121c}
.site-header{background:rgba(10,17,26,.95)}
.hero-studio{background:radial-gradient(ellipse at 75% 30%,#19405c80,transparent 55%),linear-gradient(145deg,#111b29 0%,#0b111b 65%,#0f1726 100%);padding:78px 0 90px}
.hero-stage{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(320px,.85fr);align-items:center;gap:clamp(24px,5vw,70px)}
.hero-copy h1{font-size:clamp(2.8rem,5.6vw,5.15rem);line-height:1.07;letter-spacing:-.055em;margin:.25em 0}
.hero-sub{letter-spacing:.16em;color:#aaf1ff;font-weight:800;font-size:.86rem;margin-bottom:25px}
.hero-copy .lead{line-height:1.55;font-size:1.19rem;color:#ecf5ff}
.hero-copy p:not(.lead){max-width:710px}
.hero-dashboard{border:1px solid #4c6885;border-radius:24px;padding:23px;box-shadow:0 30px 90px #020b16bb,0 0 0 5px #2a455133;background:linear-gradient(155deg,#24384d,#152131 55%,#101a27);transform:rotate(1deg)}
.dashboard-label{font-size:.7rem;letter-spacing:.14em;color:#a8d9e7;font-weight:850;border-bottom:1px solid #40536a;padding-bottom:17px}
.signal{display:inline-block;width:9px;height:9px;background:#47d78c;border-radius:100%;margin-right:8px}
.dashboard-top{display:flex;justify-content:space-between;gap:10px;align-items:center;margin:22px 0}.dashboard-top strong{font-size:1.13rem}.dashboard-tag{border:1px solid #4c8d96;color:#adf0ff;border-radius:100px;font-size:.73rem;padding:4px 9px}
.dashboard-actions{display:grid;grid-template-columns:1fr;gap:8px}.dashboard-actions span{display:flex;align-items:center;gap:12px;background:#0e1b2c;border:1px solid #30465d;border-radius:11px;padding:10px 12px;font-size:.9rem;color:#98adbf}.dashboard-actions b{color:#fff;flex:1}.dashboard-actions em{font-size:.72rem;color:#82dbfc;font-style:normal}.dashboard-actions span:nth-child(5){border-color:#648b65;background:#1b302b}
.dashboard-foot{font-size:.78rem;color:#adc2d5;margin:18px 0 0}
.takeaway{border-radius:15px;border:1px solid #537e82;background:#122d35;padding:18px 20px;margin:26px 0}.takeaway h2{font-size:1.44rem;margin:.3rem 0 1rem}.takeaway .eyebrow{margin:0}
.resource-inline{margin:28px 0;border-top:1px solid #3e5569;padding-top:24px}.step-next{font-weight:700}
.article .lead{font-size:1.12rem;color:#d8eaf5}.article .card{margin:24px 0}
@media(max-width:920px){.hero-stage{grid-template-columns:1fr}.hero-dashboard{max-width:650px;transform:none}.hero-studio{padding:54px 0}}
@media(max-width:570px){.hero-dashboard{padding:15px}.hero-copy h1{font-size:2.65rem}.hero-sub{letter-spacing:.09em}}
''',encoding='utf8')
# Accurate, GitHub-specific instructions and counts after the editorial pass.
readme=f'''# Herculist Subscriber — GitHub Pages edition

**Working project:** A complete static-site repository with one homepage, 100 educational guide HTML files, nine legal notices, a newsletter page and a browser-local 7X planner. Refreshed homepage and guide text are based on the editable source briefs in `config/guides.txt`.

**Audience:** Affiliate marketers organizing truthful ads, not a platform-bypassing autoposter.

## One-package GitHub upload (GitHub Desktop, easiest)

1. Extract the downloadable ZIP. Do **not** upload the ZIP itself as the website; GitHub needs the files inside it.
2. Create a new GitHub repository, for example `herculist-subscriber` on its `main` branch.
3. In GitHub Desktop choose **File > Add Local Repository**. If this extracted folder is not yet a repository, choose **Create a repository here**, then **Publish repository**. Alternatively, push with Git in the terminal (below).
4. In your repository open **Settings > Pages > Build and deployment > Source > GitHub Actions**.
5. In **Actions**, the included `.github/workflows/pages.yml` should build and deploy automatically on a push to `main`. The repository name and account name are detected automatically.
6. After publishing, use the Pages URL reported by the successful deployment. Test links, form actions, calculator, screen-reader basics, checkout and third-party widgets on a real phone and desktop.

### Command-line alternative (in extracted folder)

```bash
git init -b main
git add .
git commit -m "Create Herculist Subscriber GitHub Pages site"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

Replace both placeholders with your actual username and repository. Sign in through GitHub's supported authentication methods; never commit access tokens.

## How publication works

The workflow executes these commands automatically:

```bash
python3 scripts/build.py
python3 scripts/refresh_editorial.py
python3 scripts/prepare_pages.py --repository "$GITHUB_REPOSITORY"
python3 scripts/validate_publish.py _site
```

This builds the full site into `_site/` for the GitHub Pages artifact and updates path prefixes, canonical URLs, Open Graph URLs, structured-data URLs, robots.txt and sitemap.xml. The source repo intentionally contains root-oriented HTML; **the published `_site` output has the corrected GitHub Pages URLs**. This also works for the special `USERNAME.github.io` repository without a subdirectory.

### Preview a GitHub Pages-style build locally

```bash
python3 scripts/build.py
python3 scripts/refresh_editorial.py
python3 scripts/prepare_pages.py --repository exampleuser/herculist-subscriber
python3 scripts/validate_publish.py _site
python3 -m http.server 8080 --directory _site
```

Local `/herculist-subscriber/` previews require mounting `_site` at that path or simply testing individual HTML files through a server. For simple root previews, use the root site by running `python3 -m http.server 8080` and opening `/index.html`.

### Custom domain or an existing Wasmer production site

If GitHub Pages will be the **primary** site at a custom HTTPS address, first configure your custom domain and DNS in GitHub Settings, then set the GitHub Actions variable `SITE_URL` to that actual HTTPS public URL. The build will use it in canonical and sitemap entries. A GitHub Actions variable alone cannot connect a domain or establish DNS ownership.

Do not run a duplicate public SEO site on GitHub Pages and Wasmer without selecting one primary canonical site. If using GitHub only to version-control a Wasmer deployment, do not enable GitHub Pages at all; deploy the generated root files through your Wasmer workflow.

## Shipped functionality and candid limitations

- Working in a browser: campaign records, local ad drafts, seven planning tasks, self-entered observations, JSON backup import/export, time/advertising calculators and downloadable CSV planning sheets.
- The seven activities **are not seven automated Herculist postings**. There is no Herculist authorized API connection or bypass capability.
- No paid login, secure entitlement storage, WarriorPlus order fulfillment, multi-device sync, server-backed data, proven ROI, or live sales attribution.
- The WarriorPlus button and widget use supplied code but the offer was observed in test mode in the previous review. Current billing, refunds, access delivery and commercial terms require real vendor checks **before taking payments**.
- SendSteed form is present with consent checkbox; confirm double opt-in where required, provider receipts, unsubscribe links, required sender identification and policy compliance before mailing.
- Opt-in Google Analytics measurement ID `G-JSTXEL562F` and verification token `g_9a3iWAxqoXSpLnCUlYJ4fH82gOT8k0X8KF8OoleBY` are configured; validate property ownership for the **actual GitHub Pages address** and check events in GA4.
- Supplied external affiliate destinations live in `config/links.json`; several remain unverified or have referral errors. Recheck before making claims.
- GitHub Pages publishes public static files. Do **not** commit passwords, payment secrets, subscriber data or private customers' notes.

## Editorial and Google Search standards

This refreshed edition counts **{total:,} editorial words** across 100 guides (count from generated article text). That count intentionally prioritizes practical lessons over a 100,000-word target padded with generic passages. Pages include distinct seed-level aims, scenarios, practice assignments and risks. Nonetheless, a specialist must check accuracy, uniqueness and depth before pursuing broad indexing. Automatic generation and static technical checks do not guarantee compliance, search visibility or ranking.

See `QA_REPORT.md` for the static check summary. For project edits, update `config/guides.txt`, `scripts/refresh_editorial.py`, and the shared CSS, then rebuild. Generated HTML is overwritten on the next workflow run, so do not edit only those outputs.

## Project operator

Awan Elite Affiliate Services · awanraheel0@gmail.com · Copyright © 2026.
'''
(ROOT/'README.md').write_text(readme,encoding='utf8')
report=f'''# GitHub Pages Edition — QA and Release Gate

Generated: October 23, 2026

- Educational guide count: **{len(SEEDS)}**
- Counted guide article words: **{total:,}** (regex word-token count excluding navigation and shared site chrome; not a guarantee of fully researched or unique prose)
- Sitemap entries: **112** (100 guides, homepage, guide index, newsletter page, 9 legal pages)
- Static HTML files: **115**
- Checkout: exact supplied WarriorPlus button, widget and disclaimer included (LIVE CHECKOUT NOT VERIFIED)
- Newsletter: SendSteed email, name, consent and supplied IDs included (submission and unsubscribe NOT VERIFIED)
- Analytics: implemented after opt-in, not verified in production
- Customer login, paid fulfillment and Herculist automatic posting: **NOT IMPLEMENTED**
- GitHub Actions workflow: included; actual GitHub deployment requires repository configuration and a successful workflow run
- GitHub Pages project-site path handling: produced by `scripts/prepare_pages.py`, checked by `scripts/validate_publish.py`

## Manual checks required before a commercial launch

1. Build and deploy from the final repository; confirm GitHub Pages succeeds.
2. Verify the published canonical URLs, sitemap, robots and Google Search Console property for the final host.
3. Test homepage navigation, calculator, planner save/export/import, newsletter consent and phone layout in actual browsers.
4. Confirm SendSteed form acceptance, proof of consent, unsubscribe and sender identity under relevant email laws.
5. Confirm actual WarriorPlus checkout mode, vendor billing terms, prices, tax, refund rules, product fulfillment and secure customer-access design.
6. Check supplied affiliate link destinations and source disclosures.
7. Complete an editorial fact-check and distinct-content review of the 100 guides; prioritize reader quality rather than a fixed page or word quota.
8. Obtain legal and privacy review suitable for the operator's jurisdiction.

**Do not claim this website auto-posts to Herculist, proves customer savings, or authenticates paid subscribers.**
'''
(ROOT/'QA_REPORT.md').write_text(report,encoding='utf8')
print('Homepage rewritten and visual system refreshed; GitHub-specific README and QA updated')
