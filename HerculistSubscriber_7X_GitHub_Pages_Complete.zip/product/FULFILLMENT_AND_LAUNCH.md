# Commercial launch and fulfillment requirements

## Current implementation

The downloadable customer-facing assets are the local browser planner and public training files. At present these are freely accessible without authentication. The static package does not implement membership verification, paid product provisioning or an order webhook. Do not imply secure customer-only access.

## Before accepting payment

1. Verify the checkout is LIVE rather than TEST MODE. Read final product identifier, vendor ownership, USD price, any renewal timing, cancellation and refund terms in the actual WarriorPlus vendor dashboard. Do not guess or scrape credentials.
2. Configure buyer product delivery via WarriorPlus's authorized vendor delivery/membership workflow or a secure backend. Only server-side purchase confirmation should grant paid entitlements.
3. Decide whether public planner/free guides form a free tier or whether a new protected premium package is required. Do not market the current open content as exclusive paid access.
4. Confirm receipt email, access instructions, support email, and a successful end-to-end authorized purchase and refund test.
5. Replace launch-pending legal placeholders with accurate, reviewed documents including required business postal address and subscription details.
6. Review Herculist platform rules and verify the given Gold3 referral code. Automatic posting must remain absent without an officially authorized integration.
7. Test SendSteed opt-in, consent documentation, unsubscribe and transactional emails; audit analytics consent and vendor cookies.
8. Obtain a manual editorial review of all articles for content quality, repetition, current factual accuracy, originality and relevance.

## Customer-facing feature summary

Working: manual browser-local planner, blurbs, date-based seven task list, input-based metrics, import/export, calculators and CSV resources. Not working: external posting, cloud scheduling, live attribution, customer login, subscription-based entitlement and transaction fulfillment.
