# GitHub Pages Edition — QA and Release Gate

Generated: October 23, 2026

- Educational guide count: **100**
- Counted guide article words: **80,227** (regex word-token count excluding navigation and shared site chrome; not a guarantee of fully researched or unique prose)
- Sitemap entries: **112** (100 guides, homepage, guide index, newsletter page, 9 legal pages)
- Static HTML files: **115**
- Checkout: exact supplied WarriorPlus button, widget and disclaimer included (LIVE CHECKOUT NOT VERIFIED)
- Newsletter: SendSteed email, name, consent and supplied IDs included (submission and unsubscribe NOT VERIFIED)
- Analytics: implemented after opt-in, not verified in production
- Customer login, paid fulfillment and Herculist automatic posting: **NOT IMPLEMENTED**
- GitHub Actions workflow: included; actual GitHub deployment requires repository configuration and a successful workflow run
- GitHub Pages project-site path handling: produced by `scripts/prepare_pages.py`, checked by `scripts/validate_publish.py`

## Manual checks required before a commercial launch

1. Build and deploy from the final repository; confirm GitHub Pages succeeds.
2. Verify the published canonical URLs, sitemap, robots and Google Search Console property for the final host.
3. Test homepage navigation, calculator, planner save/export/import, newsletter consent and phone layout in actual browsers.
4. Confirm SendSteed form acceptance, proof of consent, unsubscribe and sender identity under relevant email laws.
5. Confirm actual WarriorPlus checkout mode, vendor billing terms, prices, tax, refund rules, product fulfillment and secure customer-access design.
6. Check supplied affiliate link destinations and source disclosures.
7. Complete an editorial fact-check and distinct-content review of the 100 guides; prioritize reader quality rather than a fixed page or word quota.
8. Obtain legal and privacy review suitable for the operator's jurisdiction.

**Do not claim this website auto-posts to Herculist, proves customer savings, or authenticates paid subscribers.**
