# Herculist Subscriber — GitHub Pages edition

**Working project:** A complete static-site repository with one homepage, 100 educational guide HTML files, nine legal notices, a newsletter page and a browser-local 7X planner. Refreshed homepage and guide text are based on the editable source briefs in `config/guides.txt`.

**Audience:** Affiliate marketers organizing truthful ads, not a platform-bypassing autoposter.

## One-package GitHub upload (GitHub Desktop, easiest)

1. Extract the downloadable ZIP. Do **not** upload the ZIP itself as the website; GitHub needs the files inside it.
2. Create a new GitHub repository, for example `herculist-subscriber` on its `main` branch.
3. In GitHub Desktop choose **File > Add Local Repository**. If this extracted folder is not yet a repository, choose **Create a repository here**, then **Publish repository**. Alternatively, push with Git in the terminal (below).
4. In your repository open **Settings > Pages > Build and deployment > Source > GitHub Actions**.
5. In **Actions**, the included `.github/workflows/pages.yml` should build and deploy automatically on a push to `main`. The repository name and account name are detected automatically.
6. After publishing, use the Pages URL reported by the successful deployment. Test links, form actions, calculator, screen-reader basics, checkout and third-party widgets on a real phone and desktop.

### Command-line alternative (in extracted folder)

```bash
git init -b main
git add .
git commit -m "Create Herculist Subscriber GitHub Pages site"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

Replace both placeholders with your actual username and repository. Sign in through GitHub's supported authentication methods; never commit access tokens.

## How publication works

The workflow executes these commands automatically:

```bash
python3 scripts/build.py
python3 scripts/refresh_editorial.py
python3 scripts/prepare_pages.py --repository "$GITHUB_REPOSITORY"
python3 scripts/validate_publish.py _site
```

This builds the full site into `_site/` for the GitHub Pages artifact and updates path prefixes, canonical URLs, Open Graph URLs, structured-data URLs, robots.txt and sitemap.xml. The source repo intentionally contains root-oriented HTML; **the published `_site` output has the corrected GitHub Pages URLs**. This also works for the special `USERNAME.github.io` repository without a subdirectory.

### Preview a GitHub Pages-style build locally

```bash
python3 scripts/build.py
python3 scripts/refresh_editorial.py
python3 scripts/prepare_pages.py --repository exampleuser/herculist-subscriber
python3 scripts/validate_publish.py _site
python3 -m http.server 8080 --directory _site
```

Local `/herculist-subscriber/` previews require mounting `_site` at that path or simply testing individual HTML files through a server. For simple root previews, use the root site by running `python3 -m http.server 8080` and opening `/index.html`.

### Custom domain or an existing Wasmer production site

If GitHub Pages will be the **primary** site at a custom HTTPS address, first configure your custom domain and DNS in GitHub Settings, then set the GitHub Actions variable `SITE_URL` to that actual HTTPS public URL. The build will use it in canonical and sitemap entries. A GitHub Actions variable alone cannot connect a domain or establish DNS ownership.

Do not run a duplicate public SEO site on GitHub Pages and Wasmer without selecting one primary canonical site. If using GitHub only to version-control a Wasmer deployment, do not enable GitHub Pages at all; deploy the generated root files through your Wasmer workflow.

## Shipped functionality and candid limitations

- Working in a browser: campaign records, local ad drafts, seven planning tasks, self-entered observations, JSON backup import/export, time/advertising calculators and downloadable CSV planning sheets.
- The seven activities **are not seven automated Herculist postings**. There is no Herculist authorized API connection or bypass capability.
- No paid login, secure entitlement storage, WarriorPlus order fulfillment, multi-device sync, server-backed data, proven ROI, or live sales attribution.
- The WarriorPlus button and widget use supplied code but the offer was observed in test mode in the previous review. Current billing, refunds, access delivery and commercial terms require real vendor checks **before taking payments**.
- SendSteed form is present with consent checkbox; confirm double opt-in where required, provider receipts, unsubscribe links, required sender identification and policy compliance before mailing.
- Opt-in Google Analytics measurement ID `G-JSTXEL562F` and verification token `g_9a3iWAxqoXSpLnCUlYJ4fH82gOT8k0X8KF8OoleBY` are configured; validate property ownership for the **actual GitHub Pages address** and check events in GA4.
- Supplied external affiliate destinations live in `config/links.json`; several remain unverified or have referral errors. Recheck before making claims.
- GitHub Pages publishes public static files. Do **not** commit passwords, payment secrets, subscriber data or private customers' notes.

## Editorial and Google Search standards

This refreshed edition counts **80,227 editorial words** across 100 guides (count from generated article text). That count intentionally prioritizes practical lessons over a 100,000-word target padded with generic passages. Pages include distinct seed-level aims, scenarios, practice assignments and risks. Nonetheless, a specialist must check accuracy, uniqueness and depth before pursuing broad indexing. Automatic generation and static technical checks do not guarantee compliance, search visibility or ranking.

See `QA_REPORT.md` for the static check summary. For project edits, update `config/guides.txt`, `scripts/refresh_editorial.py`, and the shared CSS, then rebuild. Generated HTML is overwritten on the next workflow run, so do not edit only those outputs.

## Project operator

Awan Elite Affiliate Services · awanraheel0@gmail.com · Copyright © 2026.
